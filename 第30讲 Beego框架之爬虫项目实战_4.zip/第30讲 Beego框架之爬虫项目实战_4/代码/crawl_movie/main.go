package main

import (
	_ "crawl_movie/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}

