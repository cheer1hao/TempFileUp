package linterTest

func secondFunc() error {

}
