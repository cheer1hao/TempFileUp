// +build randomtag

package main

import "fmt"

func main() {
	fmt.Prinln("hello")
}
