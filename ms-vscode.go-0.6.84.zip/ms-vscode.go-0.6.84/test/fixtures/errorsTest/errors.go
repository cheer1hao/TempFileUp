package main

import (
	"fmt"
)

func Print2(txt string) {
	fmt.Println(txt)
}
func main2() {
	prin("Hello")
}
