package main

import (
	"fmt"
)

func print(txt string) {
	fmt.Println(txt)
}
func main() {
	print("Hello")
}