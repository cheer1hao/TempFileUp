package main

import (
	"net/http"
)

func main() {
	_ = http.Client{}
}
