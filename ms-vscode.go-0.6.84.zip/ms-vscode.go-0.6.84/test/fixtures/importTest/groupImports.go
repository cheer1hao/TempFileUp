package hello

import (
	"fmt"
	"math"
)

func one() {
	fmt.Print(math.Max(1, 2))
}
