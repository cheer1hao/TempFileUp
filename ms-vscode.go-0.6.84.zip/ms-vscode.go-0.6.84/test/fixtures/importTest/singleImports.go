package hello

import "fmt"
import . "math" // comment

func two() {
	fmt.Print(Max(1, 2))
}
